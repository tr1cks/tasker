--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.worklogentry DROP CONSTRAINT fk_worklogentry_task;
ALTER TABLE ONLY public.worklogentry DROP CONSTRAINT fk_worklogentry_person;
ALTER TABLE ONLY public.taskcomment DROP CONSTRAINT fk_taskcomment_task;
ALTER TABLE ONLY public.taskcomment DROP CONSTRAINT fk_taskcomment_person;
ALTER TABLE ONLY public.task DROP CONSTRAINT fk_task_type;
ALTER TABLE ONLY public.task DROP CONSTRAINT fk_task_project;
ALTER TABLE ONLY public.task DROP CONSTRAINT fk_task_priority;
ALTER TABLE ONLY public.task DROP CONSTRAINT fk_task_person;
DROP INDEX public.worklogentry_taskid_idx;
DROP INDEX public.worklogentry_authorid_idx;
DROP INDEX public.taskcomment_taskid_idx;
DROP INDEX public.taskcomment_authorid_idx;
DROP INDEX public.task_typeid_idx;
DROP INDEX public.task_projectid_idx;
DROP INDEX public.task_priorityid_idx;
DROP INDEX public.task_assigneeid_idx;
ALTER TABLE ONLY public.worklogentry DROP CONSTRAINT worklogentry_pkey;
ALTER TABLE ONLY public.tasktype DROP CONSTRAINT uk_pxjpsxp327cmjc4ooremfnnp8;
ALTER TABLE ONLY public.taskpriority DROP CONSTRAINT uk_k4dyonj26rpnan2iswe0yq5yq;
ALTER TABLE ONLY public.taskpriority DROP CONSTRAINT uk_jxdb8d81l3owpdv335pgc3mpx;
ALTER TABLE ONLY public.project DROP CONSTRAINT uk_iflk2yk9ma95q0q9ovhftpi63;
ALTER TABLE ONLY public.task DROP CONSTRAINT uk_awswgpgqdgcos1g5t6wehc24m;
ALTER TABLE ONLY public.person DROP CONSTRAINT uk_585qcyc8qh7bg1fwgm1pj4fus;
ALTER TABLE ONLY public.tasktype DROP CONSTRAINT tasktype_pkey;
ALTER TABLE ONLY public.taskpriority DROP CONSTRAINT taskpriority_pkey;
ALTER TABLE ONLY public.taskcomment DROP CONSTRAINT taskcomment_pkey;
ALTER TABLE ONLY public.task DROP CONSTRAINT task_pkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
ALTER TABLE ONLY public.person DROP CONSTRAINT person_pkey;
DROP TABLE public.worklogentry;
DROP TABLE public.tasktype;
DROP TABLE public.taskpriority;
DROP TABLE public.taskcomment;
DROP TABLE public.task;
DROP TABLE public.project;
DROP TABLE public.person;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: person; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE person (
    id character varying(255) NOT NULL,
    email character varying(200) NOT NULL,
    password character varying(30) NOT NULL,
    firstname character varying(30) NOT NULL,
    lastname character varying(30) NOT NULL,
    removed boolean NOT NULL
);


ALTER TABLE public.person OWNER TO trickster;

--
-- Name: project; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE project (
    id character varying(32) NOT NULL,
    name character varying(30) NOT NULL,
    description character varying(200)
);


ALTER TABLE public.project OWNER TO trickster;

--
-- Name: task; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE task (
    id character varying(32) NOT NULL,
    name character varying(30) NOT NULL,
    description character varying(200) NOT NULL,
    estimatedtimeinhours integer NOT NULL,
    closed boolean NOT NULL,
    typeid character varying(32) NOT NULL,
    assigneeid character varying(32) NOT NULL,
    priorityid character varying(32) NOT NULL,
    projectid character varying(32) NOT NULL,
    CONSTRAINT task_estimatedtimeinhours_check CHECK (((estimatedtimeinhours <= 80) AND (estimatedtimeinhours >= 1)))
);


ALTER TABLE public.task OWNER TO trickster;

--
-- Name: taskcomment; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE taskcomment (
    id character varying(32) NOT NULL,
    text character varying(200) NOT NULL,
    created timestamp without time zone NOT NULL,
    authorid character varying(32) NOT NULL,
    taskid character varying(32) NOT NULL
);


ALTER TABLE public.taskcomment OWNER TO trickster;

--
-- Name: taskpriority; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE taskpriority (
    id character varying(32) NOT NULL,
    name character varying(30) NOT NULL,
    ordernum integer NOT NULL
);


ALTER TABLE public.taskpriority OWNER TO trickster;

--
-- Name: tasktype; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE tasktype (
    id character varying(32) NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE public.tasktype OWNER TO trickster;

--
-- Name: worklogentry; Type: TABLE; Schema: public; Owner: trickster; Tablespace: 
--

CREATE TABLE worklogentry (
    id character varying(32) NOT NULL,
    text character varying(200) NOT NULL,
    hours integer NOT NULL,
    created timestamp without time zone NOT NULL,
    authorid character varying(32) NOT NULL,
    taskid character varying(32) NOT NULL,
    CONSTRAINT worklogentry_hours_check CHECK (((hours >= 1) AND (hours <= 8)))
);


ALTER TABLE public.worklogentry OWNER TO trickster;

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY person (id, email, password, firstname, lastname, removed) FROM stdin;
\.
COPY person (id, email, password, firstname, lastname, removed) FROM '$$PATH$$/2863.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY project (id, name, description) FROM stdin;
\.
COPY project (id, name, description) FROM '$$PATH$$/2864.dat';

--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY task (id, name, description, estimatedtimeinhours, closed, typeid, assigneeid, priorityid, projectid) FROM stdin;
\.
COPY task (id, name, description, estimatedtimeinhours, closed, typeid, assigneeid, priorityid, projectid) FROM '$$PATH$$/2865.dat';

--
-- Data for Name: taskcomment; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY taskcomment (id, text, created, authorid, taskid) FROM stdin;
\.
COPY taskcomment (id, text, created, authorid, taskid) FROM '$$PATH$$/2866.dat';

--
-- Data for Name: taskpriority; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY taskpriority (id, name, ordernum) FROM stdin;
\.
COPY taskpriority (id, name, ordernum) FROM '$$PATH$$/2867.dat';

--
-- Data for Name: tasktype; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY tasktype (id, name) FROM stdin;
\.
COPY tasktype (id, name) FROM '$$PATH$$/2868.dat';

--
-- Data for Name: worklogentry; Type: TABLE DATA; Schema: public; Owner: trickster
--

COPY worklogentry (id, text, hours, created, authorid, taskid) FROM stdin;
\.
COPY worklogentry (id, text, hours, created, authorid, taskid) FROM '$$PATH$$/2869.dat';

--
-- Name: person_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id);


--
-- Name: project_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: task_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: taskcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY taskcomment
    ADD CONSTRAINT taskcomment_pkey PRIMARY KEY (id);


--
-- Name: taskpriority_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY taskpriority
    ADD CONSTRAINT taskpriority_pkey PRIMARY KEY (id);


--
-- Name: tasktype_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY tasktype
    ADD CONSTRAINT tasktype_pkey PRIMARY KEY (id);


--
-- Name: uk_585qcyc8qh7bg1fwgm1pj4fus; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY person
    ADD CONSTRAINT uk_585qcyc8qh7bg1fwgm1pj4fus UNIQUE (email);


--
-- Name: uk_awswgpgqdgcos1g5t6wehc24m; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY task
    ADD CONSTRAINT uk_awswgpgqdgcos1g5t6wehc24m UNIQUE (name);


--
-- Name: uk_iflk2yk9ma95q0q9ovhftpi63; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT uk_iflk2yk9ma95q0q9ovhftpi63 UNIQUE (name);


--
-- Name: uk_jxdb8d81l3owpdv335pgc3mpx; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY taskpriority
    ADD CONSTRAINT uk_jxdb8d81l3owpdv335pgc3mpx UNIQUE (name);


--
-- Name: uk_k4dyonj26rpnan2iswe0yq5yq; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY taskpriority
    ADD CONSTRAINT uk_k4dyonj26rpnan2iswe0yq5yq UNIQUE (ordernum);


--
-- Name: uk_pxjpsxp327cmjc4ooremfnnp8; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY tasktype
    ADD CONSTRAINT uk_pxjpsxp327cmjc4ooremfnnp8 UNIQUE (name);


--
-- Name: worklogentry_pkey; Type: CONSTRAINT; Schema: public; Owner: trickster; Tablespace: 
--

ALTER TABLE ONLY worklogentry
    ADD CONSTRAINT worklogentry_pkey PRIMARY KEY (id);


--
-- Name: task_assigneeid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX task_assigneeid_idx ON task USING btree (assigneeid);


--
-- Name: task_priorityid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX task_priorityid_idx ON task USING btree (priorityid);


--
-- Name: task_projectid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX task_projectid_idx ON task USING btree (projectid);


--
-- Name: task_typeid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX task_typeid_idx ON task USING btree (typeid);


--
-- Name: taskcomment_authorid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX taskcomment_authorid_idx ON taskcomment USING btree (authorid);


--
-- Name: taskcomment_taskid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX taskcomment_taskid_idx ON taskcomment USING btree (taskid);


--
-- Name: worklogentry_authorid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX worklogentry_authorid_idx ON worklogentry USING btree (authorid);


--
-- Name: worklogentry_taskid_idx; Type: INDEX; Schema: public; Owner: trickster; Tablespace: 
--

CREATE INDEX worklogentry_taskid_idx ON worklogentry USING btree (taskid);


--
-- Name: fk_task_person; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk_task_person FOREIGN KEY (assigneeid) REFERENCES person(id);


--
-- Name: fk_task_priority; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk_task_priority FOREIGN KEY (priorityid) REFERENCES taskpriority(id);


--
-- Name: fk_task_project; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk_task_project FOREIGN KEY (projectid) REFERENCES project(id);


--
-- Name: fk_task_type; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY task
    ADD CONSTRAINT fk_task_type FOREIGN KEY (typeid) REFERENCES tasktype(id);


--
-- Name: fk_taskcomment_person; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY taskcomment
    ADD CONSTRAINT fk_taskcomment_person FOREIGN KEY (authorid) REFERENCES person(id);


--
-- Name: fk_taskcomment_task; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY taskcomment
    ADD CONSTRAINT fk_taskcomment_task FOREIGN KEY (taskid) REFERENCES task(id);


--
-- Name: fk_worklogentry_person; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY worklogentry
    ADD CONSTRAINT fk_worklogentry_person FOREIGN KEY (authorid) REFERENCES person(id);


--
-- Name: fk_worklogentry_task; Type: FK CONSTRAINT; Schema: public; Owner: trickster
--

ALTER TABLE ONLY worklogentry
    ADD CONSTRAINT fk_worklogentry_task FOREIGN KEY (taskid) REFERENCES task(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

